﻿namespace NewJWT.Users
{
    public class Response
    {
        public string Message { get; set; } = String.Empty;
        public string token { get; set; }
    }
}
